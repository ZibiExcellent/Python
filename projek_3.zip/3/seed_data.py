import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, Experiment, DataPoint, Subject

DB_FILE = "lab.db"
engine = create_engine(f"sqlite:///{DB_FILE}", echo=True)
Session = sessionmaker(bind=engine)
session = Session()

# Dodanie danych
exp1 = Experiment(title="Test A", type=1)
exp2 = Experiment(title="Test B", type=2)
session.add_all([exp1, exp2])
session.commit()

points = [DataPoint(real_value=i * 1.1, target_value=i * 1.5, experiment=exp1 if i < 5 else exp2)
          for i in range(10)]
session.add_all(points)
session.commit()

for exp in session.query(Experiment).all():
    exp.finished = True
session.commit()

session.query(DataPoint).delete()
session.query(Experiment).delete()
session.commit()

exp1 = Experiment(title="Nowy A", type=1)
exp2 = Experiment(title="Nowy B", type=2)
session.add_all([exp1, exp2])
session.commit()

sub1 = Subject(gdpr_accepted=True)
sub2 = Subject(gdpr_accepted=False)
exp1.subjects.append(sub1)
exp2.subjects.extend([sub1, sub2])
session.add_all([sub1, sub2])
session.commit()

for sub in session.query(Subject).all():
    print(f"Subject {sub.id}, GDPR: {sub.gdpr_accepted}, Experiments: {[e.title for e in sub.experiments]}")
